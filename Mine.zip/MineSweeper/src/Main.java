
import java.io.File;
import java.util.Random;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseButton;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Main extends Application{
	public static void main(String[] args) {
		Application.launch(args); 
	}
	
	private int numMines;
	private int size;
	private int level;
	private int scenesize;
	private Text flag;
	private Stage primaryStage;
	private Scene scene1;
	private Scene scene2;
	private Scene scene3;
	private Scene scene4;
	private Scene scene5;
	private int seconds = 0;
    private Label timerLabel = new Label("Time：0s");
    private Timeline timeline;
    private GridPane grid1;
    private GridPane grid2;
	private int flaggedMines=0;
    
	@Override
	public void start(Stage primaryStage) { 
		this.primaryStage = primaryStage;
		primaryStage.setTitle("MineSweeper");
		
		FlowPane root1 = new FlowPane(); 
		root1.setAlignment(Pos.CENTER);
		Label titleLabel = new Label("MineSweeper"); 
		Button btn1 = new Button("Start");
		btn1.setOnAction(e -> {
			switchToScene4();			
		});
		Button btn2 = new Button("Challenge");
		btn2.setOnAction(e -> switchToScene5());
		Button btn3 = new Button("Settings");
		VBox box = new VBox(); //将label，2 button分层，排成三行；如果没有Vbox会直接排成一行
		box.setSpacing(10);
		box.setAlignment(Pos.CENTER);
		box.getChildren().addAll(titleLabel, btn1, btn2, btn3);
		
    	/*Media media = new Media("bgm.mp3");
        MediaPlayer mediaPlayer = new MediaPlayer(media);
        MediaView view = new MediaView(mediaPlayer);
        mediaPlayer.play();*/
		
		scene1 = new Scene(root1, 500, 500);
		scene1.getStylesheets().add(Main.class.getResource("mycss.css").toExternalForm());
		root1.getChildren().addAll(box);
		
		primaryStage.setScene(scene1);
		primaryStage.show(); 
	}
	
	 private void switchToScene1() {
	        primaryStage.setScene(scene1);
	 }

	private void switchToScene2() {
		BorderPane root = new BorderPane();
		VBox boxTop = new VBox();
		flag = new Text("FlagRest:" + level);
		flag.setFont(Font.font("Impact", FontWeight.BOLD, 24));
		flag.setFill(Color.WHITE);
		HBox hBox = new HBox();
		hBox.setSpacing(10);
		Button restart = new Button("Restart");
		restart.setOnAction(e -> {
			switchToScene1();
		});		
		Button rule = new Button("Rule");
		rule.setOnAction(e -> {
			ruleWindow();
		});		
		hBox.getChildren().addAll(restart, rule);
		boxTop.getChildren().addAll(flag, hBox);
		grid1 = grid(); 
		scene2 = new Scene(root, scenesize, scenesize);
		scene2.getStylesheets().add(Main.class.getResource("scene2.css").toExternalForm());
		root.setTop(boxTop);
		root.setCenter(grid1);
        primaryStage.setScene(scene2);
    }
    
    private void switchToScene3() {
    	BorderPane root3 = new BorderPane();
		VBox boxTopC = new VBox();
		HBox hBoxC = new HBox();
		flag = new Text("FlagRest:" + level);
		flag.setFont(Font.font("Impact", FontWeight.BOLD, 24));
		flag.setFill(Color.WHITE);
		hBoxC.setSpacing(10);
		Button restartC = new Button("Restart");
		restartC.setOnAction(e -> {
			timeline.stop();
			seconds = 0;
			level = numMines;
			timerLabel.setText("Time：" + seconds + "s");
			switchToScene1();
		});
		Button ruleC = new Button("Rule");
		ruleC.setOnAction(e -> {
			ruleWindow();
		});		
		timerLabel.getStyleClass().add("time-label");
		hBoxC.setSpacing(10);		
		hBoxC.getChildren().addAll(restartC, ruleC, timerLabel);
		boxTopC.getChildren().addAll(flag, hBoxC);
		grid2 = grid();
		scene3 = new Scene(root3, scenesize, scenesize);
		scene3.getStylesheets().add(Main.class.getResource("scene2.css").toExternalForm());
		root3.setTop(boxTopC);
		root3.setCenter(grid2);
        primaryStage.setScene(scene3);
        timeline = new Timeline(
	            new KeyFrame(Duration.seconds(1), new EventHandler<ActionEvent>() {
	                @Override
	                public void handle(ActionEvent event) {
	                    seconds++;
	                    timerLabel.setText("Time：" + seconds + "s");
	                    
	                    if(seconds >= 10) {
	                    	timeline.stop();
	                    	seconds = 0;
	            			timerLabel.setText("Time：" + seconds + "s");
	                    	loseWindow();
	                    }
	                }
	            })
	      );
	      timeline.setCycleCount(Timeline.INDEFINITE); // 无限循环
	      timeline.play(); // 启动时间线动画
    }
    
    private void switchToScene4() {
       	ImageView matchstick = new ImageView(new Image("/image/match.png"));
        ImageView easyBomb = new ImageView(new Image("/image/easy.png"));
        ImageView hardBomb = new ImageView(new Image("/image/hard.png"));
        
        matchstick.setFitWidth(100);  
        matchstick.setFitHeight(100); 
        easyBomb.setFitWidth(150);  
        easyBomb.setFitHeight(150); 
        hardBomb.setFitWidth(150);  
        hardBomb.setFitHeight(150);
        FlowPane root4 = new FlowPane();
        // Add your image views to the pane.
        root4.setAlignment(Pos.CENTER);
		VBox vbox = new VBox();
		vbox.setAlignment(Pos.CENTER);
		Label title = new Label("Drag the match to detonate the bomb");
		title.setFont(Font.font("Impact", 36));
		title.setTextFill(Color.ORANGE);
		Label titleLabel = new Label("To choose your level"); 
		titleLabel.setFont(Font.font("Impact", 36));
		titleLabel.setTextFill(Color.ORANGE);
		HBox hbox = new HBox();
		hbox.setSpacing(10);
		hbox.getChildren().addAll(easyBomb, matchstick, hardBomb);
		hbox.setAlignment(Pos.CENTER);
		vbox.getChildren().addAll(title, titleLabel, hbox);
		vbox.setSpacing(50);
        root4.getChildren().add(vbox);

        matchstick.setOnDragDetected(event -> {
             Dragboard db = matchstick.startDragAndDrop(TransferMode.ANY);
             ClipboardContent content = new ClipboardContent();
             content.putImage(matchstick.getImage());
             db.setContent(content);
             event.consume();
         });

        easyBomb.setOnDragOver(event -> {
        	if (event.getDragboard().hasImage()) {
                 event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
             }
             event.consume();
        });

        easyBomb.setOnDragDropped(event -> {
        	this.scenesize = 500;
			this.size = 5;
        	this.numMines = 2;
        	this.level = 2;
        	switchToScene2();
         });
        
        hardBomb.setOnDragOver(event -> {
        	if (event.getDragboard().hasImage()) {
                 event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
             }
             event.consume();
        });

        hardBomb.setOnDragDropped(event -> {
        	this.size = 10;
        	this.scenesize = 600;
        	this.numMines = 5;
        	this.level = 5;
        	switchToScene2();
         });
        scene4 = new Scene(root4, 600, 600);
        primaryStage.setScene(scene4);
    }
    
    private void switchToScene5() {
    	FlowPane root5 = new FlowPane();  
		root5.setAlignment(Pos.CENTER);
		VBox vbox = new VBox();
		Label titleLabel = new Label("Warning!!!");
		Text text = new Text("The challenge mode has a time limit, \n" + "try to complete the challenge in a shorter time!\n" + "The level of this mode will be 'Difficult' !\n"
				+ "(Rules are the same as normal mode.)");
		text.setFont(Font.font("Impact", 20));
		HBox hbox1 = new HBox();
		hbox1.setSpacing(10);
		Label label1 = new Label("If you are ready ->");
		Button btn1 = new Button("Yes");
		btn1.setOnAction(e -> {
        	this.size = 10;
        	this.scenesize = 600;
        	this.numMines = 5;
        	this.level = 5;
        	switchToScene3();
        });
		hbox1.getChildren().addAll(label1, btn1);
		HBox hbox2 = new HBox();
		hbox2.setSpacing(10);
		Label label2 = new Label("If not ->");
		Button btn2 = new Button("No");
		btn2.setOnAction(e -> {
        	switchToScene1();
        });
		hbox2.getChildren().addAll(label2, btn2);
		vbox.getChildren().addAll(titleLabel, text, hbox1, hbox2);
		root5.getChildren().add(vbox);
		scene5 = new Scene(root5, 600, 600);
		scene5.getStylesheets().add(Main.class.getResource("warning.css").toExternalForm());
        primaryStage.setScene(scene5);
    }
    
    private void ruleWindow() {
    	Stage newStage = new Stage();
        newStage.initModality(Modality.APPLICATION_MODAL); // 使新窗口模态
        newStage.setTitle("Rules");
        VBox vbox = new VBox();
        vbox.setAlignment(Pos.CENTER);
		Text text = new Text("Minesweeper is a game where mines are hidden in a grid of squares.\n" + 
				"Safe squares have numbers telling you how many mines touch the square.\n" + 
				"You can use the number clues to solve the game by opening all of the safe squares.\n" + 
				"Adding a flag on the grid square which you think it’s mine by clicking right. \n" +
				"If you click on a mine you lose the game!");
		text.setFont(Font.font("Impact", 14));
		Button ok = new Button("OK");
	        ok.setOnAction(e -> {
	        	newStage.close();
	    });
	    vbox.getChildren().addAll(text, ok);
	    Scene secondScene = new Scene(vbox, scenesize, 200);
        newStage.setScene(secondScene);
        newStage.show();
    }
    
    private void loseWindow() {
        Stage newStage = new Stage();
        newStage.initModality(Modality.APPLICATION_MODAL);
        newStage.setTitle("Lose");
        VBox root1 = new VBox(); 
		root1.setAlignment(Pos.CENTER);
        Label la = new Label("You Lose");
        Button ok = new Button("OK");
        ok.setOnAction(e -> {
        	switchToScene1();
        	newStage.close();
        });
		root1.getChildren().addAll(la, ok);
        Scene secondScene = new Scene(root1, 200, 100);
        newStage.setScene(secondScene);
        newStage.show();
    }
    
    private void winWindow() {
        // 创建新的小窗口
        Stage newStage = new Stage();
        newStage.initModality(Modality.APPLICATION_MODAL); // 使新窗口模态
        newStage.setTitle("Win");
        VBox root1 = new VBox(); 
		root1.setAlignment(Pos.CENTER);
        Label la = new Label("You Win");
        Button ok = new Button("OK");
        ok.setOnAction(e -> {
        	switchToScene1();
        	newStage.close();
        });
		root1.getChildren().addAll(la, ok);
        Scene secondScene = new Scene(root1, 200, 100);
        // 将新窗口的场景设置为secondScene
        newStage.setScene(secondScene);
        // 显示新窗口
        newStage.show();
    }
    
    public void stop() { // 在应用关闭时停止时间线动画
        if (timeline != null) {
            timeline.stop();
        }
    }
    
    public boolean[][] setMine(){
		boolean[][] mines = new boolean[size][size];
		Random random = new Random();
        // 选择随机的10个单元格
        for (int i = 0; i < numMines; i++) {
            int row = random.nextInt(size-1); // 生成随机行索引（0到9之间）
            int col = random.nextInt(size-1); // 生成随机列索引（0到9之间）
            // 检查是否已经选择了该单元格，如果是则重新选择
            while (mines[row][col]) {
                row = random.nextInt(size-1);
                col = random.nextInt(size-1);
            }
            // 将选定的单元格设置为true
            mines[row][col] = true;
        }
        return mines;
	}
	
	public int[][] countMines(boolean[][] table) {       
        int[][] count = new int[size][size];
        int numRows = table.length;
        int numCols = table[0].length;
        // 定义相邻八个格子的相对行和列偏移
        int[] rowOffsets = {-1, -1, -1, 0, 0, 1, 1, 1};
        int[] colOffsets = {-1, 0, 1, -1, 1, -1, 0, 1};
        int trueNeighbors = 0;
        for(int m=0; m<size; m++) {        	
        	for(int n=0; n<size; n++) {
        		trueNeighbors = 0;
        		if(table[m][n]) {
        			trueNeighbors = -1;
        		}else {
        		for (int i = 0; i < 8; i++) {
        			int newRow = m + rowOffsets[i];
        			int newCol = n + colOffsets[i];
        			// 检查相邻的格子是否在表格内，并且是否为true
        			if (newRow >= 0 && newRow < numRows && newCol >= 0 && newCol < numCols && table[newRow][newCol]) {
        				trueNeighbors++;
        				}
        			}
        		}
        		count[m][n]= trueNeighbors;
        	}
        }
        return count;
    }
	
	public Label[][] mineLabel(boolean[][] mines){
		Label[][] labels = new Label[size][size];
		int[][] count = countMines(mines);
		for(int i=0; i<size;i++) {
			for(int j=0; j<size;j++) {
				if(mines[i][j]) {
					Image img = new Image("/image/boom.jpg");
                	ImageView imgV = new ImageView(img);
                	imgV.setFitWidth(45); 
                    imgV.setFitHeight(45);
                    Label mine = new Label();
                    mine.setGraphic(imgV);
					labels[i][j] = mine;
				}else {
					int c = count[i][j];
					if(c == 0) {
                		labels[i][j] = new Label();		                                		
                	}else {
                		Label la = new Label(""+ c);
                		Tooltip tool = new Tooltip("There is " + c + " bomb in the eight cells near this cell");
                		tool.setStyle("-fx-font-size: 16px;");
                		Tooltip.install(la, tool);
                		switch(c) {
                		case 1->{
                			la.setTextFill(Color.BLUE);
                		}
                		case 2->{
                			la.setTextFill(Color.GREEN);
                		}
                		case 3->{
                			la.setTextFill(Color.RED);
                		}
                		case 4->{
                			la.setTextFill(Color.ORANGE);
                		}
                		}
                		la.setFont(Font.font("Arial", FontWeight.BOLD, 16));
                		labels[i][j] = la;
                	}
				}
			}
		}
		return labels;
	}
    
    public GridPane grid() {
    	boolean[][] mines = setMine();
    	GridPane grid = new GridPane(); 
		grid.setGridLinesVisible(true);
		grid.setAlignment(Pos.CENTER);
		Button[][] buttons = new Button[size][size];
		Label[][] labels = mineLabel(mines);
		int[][] count = countMines(mines);
		for (int i=0;i<size; ++i) {
			for (int j=0; j<size;++j){
				Button btn = new Button();
				buttons[i][j] = btn;
				int row = i;
				int col = j;
				btn.setPrefSize(50, 50);
				/*btn.addEventHandler( MouseEvent.MOUSE_CLICKED, e -> { 
					btn.setText("11");
				});*/
				btn.setOnMouseClicked(event -> {
					if (event.getButton() == MouseButton.SECONDARY) { // 检查是否是右键点击		                
		                level--;
		                updateFlag();
						Image f = new Image("/image/flag.jpg");
		                ImageView fl = new ImageView(f);
		                fl.setFitWidth(48); 
	                    fl.setFitHeight(48);
	                    btn.setVisible(false);
	                    grid.add(fl, row, col);
	                    int n = count[row][col];
	                    count[row][col] = -2;
		             	if(mines[row][col]) {
		             		flaggedMines++;
		             	}
		             	fl.setOnMouseClicked(e -> {
		                    // 在点击ImageView时切换为Button
		             		level++;
		             		updateFlag();
		             		flaggedMines--;	
		             		count[row][col] = n;
		             		btn.setVisible(true);
		             		fl.setVisible(false);
		                });
		             	if (flaggedMines == numMines) {
		                    // If the game is won, show a victory window
		                    stop();
		                    flaggedMines = 0;
		                    winWindow();
		                }
		             }else {		                
		                if(!mines[row][col]) {				                			        
		                                	btn.setVisible(false); // 隐藏按钮		                  
		                                	GridPane.setHalignment(labels[row][col], javafx.geometry.HPos.CENTER);
		        		                    GridPane.setValignment(labels[row][col], javafx.geometry.VPos.CENTER);
		        		                    grid.add(labels[row][col], row, col);
		        		                    change(grid, buttons, labels, count, row, col);		        		                    
		                }else {	
		                	btn.setVisible(false);
		                    grid.add(labels[row][col], row, col);
		                    stop();
		                    flaggedMines = 0;
		                	loseWindow();
		                }
		            }
		        });				
				if(buttons[i][j] != null) {
					grid.add(buttons[i][j], i,j);
				}
			}
		}
		return grid;
    }
    
   
    private void change(GridPane grid, Button[][] buttons, Label[][] labels, int[][] count,int row, int col) {
        int numRows = buttons.length;
        int numCols = buttons[0].length;

        // Define surrounding offsets
        int[] rowOffsets = {-1, -1, -1, 0, 0, 1, 1, 1};
        int[] colOffsets = {-1, 0, 1, -1, 1, -1, 0, 1};

        for (int i = 0; i < 8; i++) {
			int newRow = row + rowOffsets[i];
			int newCol = col + colOffsets[i];

            if (newRow >= 0 && newRow < numRows && newCol >= 0 && newCol < numCols) {  
            	if(buttons[newRow][newCol] == null) {
            		continue;
            	}else {
                // Check if the button exists at the new position              
                if (count[newRow][newCol] >= 0) {              	
                	buttons[newRow][newCol].setVisible(false);
                	buttons[newRow][newCol] = null;
                	GridPane.setHalignment(labels[newRow][newCol], javafx.geometry.HPos.CENTER);
                    GridPane.setValignment(labels[newRow][newCol], javafx.geometry.VPos.CENTER);
                    grid.add(labels[newRow][newCol], newRow, newCol);
                    /*change(grid, buttons, labels, count, newRow, newCol);*/
                	}
            	}
            }
        }
    }
     
    private void updateFlag() {
    	flag.setText("FlagRest:" + level);
    }                

}
